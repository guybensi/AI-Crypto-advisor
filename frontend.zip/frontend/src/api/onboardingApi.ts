import type { PreferencesVM } from '../api/types'
const defaultState: PreferencesVM = { assets: [], investorType: 'HODLER', contentTypes: [] }
